<?php

declare(strict_types=1);

/**
 * Gilgil Technical and Vocational College (GTVC) LMS - Production Front Controller
 * Apache/Nginx Front Controller Entry Point (PHP 8.x + MySQL / MariaDB)
 */

use App\Config\AppConfig;
use App\Core\Request;
use App\Core\Router;
use App\Core\Session;

// PSR-4 Autoloader for App Namespace
spl_autoload_register(function (string $class): void {
    $prefix = 'App\\';
    $baseDir = __DIR__ . '/../app/';

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relativeClass = substr($class, $len);
    $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';

    if (file_exists($file)) {
        require_once $file;
    }
});

// Load Environment Configuration
AppConfig::loadEnv(__DIR__ . '/../.env');

// Start Secure Session Management
Session::start();

// Initialize HTTP Router
$router = new Router();

// =============================================================================
// WEB PAGE VIEWS (Server-Rendered Frontend)
// =============================================================================

$router->get('/', [App\Controllers\ViewController::class, 'home']);
$router->get('/login', [App\Controllers\ViewController::class, 'loginView']);
$router->get('/dashboard', [App\Controllers\ViewController::class, 'dashboard']);

// Student Portal Routes
$router->get('/student/courses', [App\Controllers\ViewController::class, 'studentCourses']);
$router->get('/student/materials', [App\Controllers\ViewController::class, 'studentMaterials']);
$router->get('/student/assignments', [App\Controllers\ViewController::class, 'studentAssignments']);
$router->post('/student/assignments/submit', [App\Controllers\AssignmentController::class, 'submitAssignment']);
$router->get('/student/quizzes', [App\Controllers\ViewController::class, 'studentQuizzes']);
$router->get('/student/grades', [App\Controllers\ViewController::class, 'studentGrades']);
$router->get('/student/attendance', [App\Controllers\ViewController::class, 'studentAttendance']);
$router->get('/student/announcements', [App\Controllers\ViewController::class, 'studentAnnouncements']);
$router->get('/student/profile', [App\Controllers\ViewController::class, 'studentProfile']);
$router->get('/student/fees', [App\Controllers\ViewController::class, 'studentFees']);

// Lecturer / Trainer Routes
$router->get('/lecturer/courses', [App\Controllers\ViewController::class, 'lecturerCourses']);
$router->get('/lecturer/gradebook', [App\Controllers\ViewController::class, 'lecturerGradebook']);
$router->get('/lecturer/attendance', [App\Controllers\ViewController::class, 'lecturerAttendance']);
$router->get('/lecturer/modules', [App\Controllers\ViewController::class, 'lecturerModules']);

// HOD Routes
$router->get('/hod/students', [App\Controllers\ViewController::class, 'hodStudents']);
$router->get('/hod/lecturers', [App\Controllers\ViewController::class, 'hodLecturers']);
$router->get('/hod/analytics', [App\Controllers\ViewController::class, 'hodAnalytics']);

// Accountant / Finance Routes
$router->get('/accountant/fee-structures', [App\Controllers\ViewController::class, 'accountantFeeStructures']);
$router->get('/accountant/student-accounts', [App\Controllers\ViewController::class, 'accountantStudentAccounts']);
$router->get('/accountant/payments', [App\Controllers\ViewController::class, 'accountantPayments']);
$router->get('/accountant/invoices', [App\Controllers\ViewController::class, 'accountantInvoices']);
$router->get('/accountant/clearance', [App\Controllers\ViewController::class, 'accountantClearance']);

// Administrator Routes
$router->get('/admin/users', [App\Controllers\ViewController::class, 'adminUsers']);
$router->get('/admin/academic', [App\Controllers\ViewController::class, 'adminAcademic']);
$router->get('/admin/settings', [App\Controllers\ViewController::class, 'adminSettings']);
$router->get('/admin/audit-logs', [App\Controllers\ViewController::class, 'adminAuditLogs']);

// =============================================================================
// API REST ENDPOINTS
// =============================================================================

// Auth API
$router->post('/api/v1/auth/login', [App\Controllers\AuthController::class, 'login']);
$router->post('/api/v1/auth/logout', [App\Controllers\AuthController::class, 'logout']);
$router->get('/logout', [App\Controllers\AuthController::class, 'logout']);
$router->get('/api/v1/auth/me', [App\Controllers\AuthController::class, 'me']);
$router->post('/api/v1/auth/change-password', [App\Controllers\AuthController::class, 'changePassword']);

// Admin API
$router->get('/api/v1/admin/users', [App\Controllers\AdminController::class, 'getUsers']);
$router->post('/api/v1/admin/users', [App\Controllers\AdminController::class, 'createUser']);
$router->post('/api/v1/admin/users/{id}', [App\Controllers\AdminController::class, 'updateUser']);
$router->put('/api/v1/admin/users/{id}', [App\Controllers\AdminController::class, 'updateUser']);
$router->get('/api/v1/admin/settings', [App\Controllers\AdminController::class, 'getSettings']);
$router->post('/api/v1/admin/settings', [App\Controllers\AdminController::class, 'updateSettings']);
$router->put('/api/v1/admin/settings', [App\Controllers\AdminController::class, 'updateSettings']);
$router->get('/api/v1/admin/audit-logs', [App\Controllers\AdminController::class, 'getAuditLogs']);

// Academic & Departments API
$router->get('/api/v1/academic/departments', [App\Controllers\AcademicController::class, 'getDepartments']);
$router->get('/api/v1/departments', [App\Controllers\AcademicController::class, 'getDepartments']);
$router->post('/api/v1/departments', [App\Controllers\AcademicController::class, 'createDepartment']);
$router->post('/api/v1/academic/departments', [App\Controllers\AcademicController::class, 'createDepartment']);
$router->post('/api/v1/programs', [App\Controllers\AcademicController::class, 'createProgram']);
$router->post('/api/v1/academic/programs', [App\Controllers\AcademicController::class, 'createProgram']);
$router->post('/api/v1/classes', [App\Controllers\AcademicController::class, 'createClass']);
$router->post('/api/v1/academic/classes', [App\Controllers\AcademicController::class, 'createClass']);

// Core Entities & Learning API
$router->get('/api/v1/users', [App\Controllers\AdminController::class, 'getUsers']);
$router->get('/api/v1/students', [App\Controllers\StudentController::class, 'index']);
$router->get('/api/v1/learning/materials', [App\Controllers\LearningMaterialController::class, 'getMaterials']);
$router->get('/api/v1/assignments', [App\Controllers\AssignmentController::class, 'getAssignments']);
$router->post('/api/v1/assignments/submissions', [App\Controllers\AssignmentController::class, 'submitAssignment']);
$router->post('/api/v1/assignments/{id}/submit', [App\Controllers\AssignmentController::class, 'submitAssignment']);
$router->get('/api/v1/assignments/{id}/submissions', [App\Controllers\AssignmentController::class, 'getSubmissions']);
$router->post('/api/v1/assignments/submissions/{id}/grade', [App\Controllers\AssignmentController::class, 'gradeSubmission']);
$router->post('/api/v1/assignments/grade', [App\Controllers\AssignmentController::class, 'gradeSubmission']);
$router->post('/api/v1/modules', [App\Controllers\CourseModuleController::class, 'createModule']);

// Attendance API
$router->get('/api/v1/attendance/sessions', [App\Controllers\AttendanceController::class, 'getSessions']);
$router->post('/api/v1/attendance/sessions', [App\Controllers\AttendanceController::class, 'createSession']);

// Finance API
$router->get('/api/v1/finance/summary', [App\Controllers\FinanceController::class, 'getStudentAccounts']);
$router->get('/api/v1/finance/fee-structures', [App\Controllers\FinanceController::class, 'getFeeStructures']);
$router->post('/api/v1/finance/fee-structures', [App\Controllers\FinanceController::class, 'createFeeStructure']);
$router->post('/api/v1/finance/fee-structures/{id}', [App\Controllers\FinanceController::class, 'updateFeeStructure']);
$router->put('/api/v1/finance/fee-structures/{id}', [App\Controllers\FinanceController::class, 'updateFeeStructure']);
$router->get('/api/v1/finance/payments', [App\Controllers\FinanceController::class, 'getPayments']);
$router->post('/api/v1/finance/payments', [App\Controllers\FinanceController::class, 'recordPayment']);
$router->post('/api/v1/finance/payments/{id}/verify', [App\Controllers\FinanceController::class, 'verifyPayment']);
$router->post('/api/v1/finance/invoices/generate-batch', [App\Controllers\FinanceController::class, 'generateBatchInvoices']);

// Gradebook API
$router->post('/api/v1/gradebook/publish', [App\Controllers\GradebookController::class, 'publishGrades']);

// Dispatch Request
$request = new Request();
$router->dispatch($request);
