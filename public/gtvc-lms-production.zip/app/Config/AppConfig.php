<?php

declare(strict_types=1);

namespace App\Config;

/**
 * Gilgil TVC LMS Application Configuration
 */
class AppConfig
{
    /**
     * Load environment variables from .env file if available
     */
    public static function loadEnv(string $envPath): void
    {
        if (file_exists($envPath)) {
            $lines = file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            foreach ($lines as $line) {
                $line = trim($line);
                if ($line === '' || str_starts_with($line, '#')) {
                    continue;
                }

                if (str_contains($line, '=')) {
                    [$key, $value] = explode('=', $line, 2);
                    $key = trim($key);
                    $value = trim($value, " \t\n\r\0\x0B\"'");
                    if (!array_key_exists($key, $_SERVER) && !array_key_exists($key, $_ENV)) {
                        putenv("{$key}={$value}");
                        $_ENV[$key] = $value;
                        $_SERVER[$key] = $value;
                    }
                }
            }
        }

        // Set timezone
        $timezone = self::env('APP_TIMEZONE', 'Africa/Nairobi');
        date_default_timezone_set($timezone);

        // Configure error reporting
        $debug = filter_var(self::env('APP_DEBUG', true), FILTER_VALIDATE_BOOLEAN);
        if ($debug) {
            error_reporting(E_ALL);
            ini_set('display_errors', '1');
        } else {
            error_reporting(0);
            ini_set('display_errors', '0');
        }
    }

    /**
     * Helper to read environment variables with fallback
     */
    public static function env(string $key, mixed $default = null): mixed
    {
        $value = getenv($key);
        if ($value === false) {
            return $_ENV[$key] ?? $default;
        }
        return $value;
    }

    /**
     * Check if running in production environment
     */
    public static function isProduction(): bool
    {
        $env = strtolower((string)(self::env('APP_ENV', 'production') ?: 'production'));
        return in_array($env, ['production', 'prod', 'live'], true);
    }
}
